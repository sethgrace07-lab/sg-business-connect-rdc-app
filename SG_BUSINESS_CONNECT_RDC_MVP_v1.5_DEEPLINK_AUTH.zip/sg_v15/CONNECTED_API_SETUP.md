# SG BUSINESS CONNECT RDC — Flutter + Supabase

## Connexion
L'application lit `SUPABASE_URL` et `SUPABASE_PUBLISHABLE_KEY` via `--dart-define`.

## Retrait TEST
L'écran Portefeuille appelle la RPC protégée `request_test_withdrawal` avec la session Supabase de l'utilisateur connecté. Il ne fait pas d'insert direct dans `withdrawals`.

Le retrait TEST ne déclenche aucun paiement réel. Les méthodes Airtel Money, Vodacom M-Pesa et Banque sont enregistrées comme canaux de test uniquement.

## Lancement
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL="VOTRE_URL" --dart-define=SUPABASE_PUBLISHABLE_KEY="VOTRE_CLE_PUBLIQUE"
```
