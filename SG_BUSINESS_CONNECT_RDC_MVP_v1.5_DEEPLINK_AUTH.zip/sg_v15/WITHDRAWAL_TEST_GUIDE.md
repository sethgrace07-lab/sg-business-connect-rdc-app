# SG BUSINESS CONNECT RDC v1.3 — Écran de retrait TEST

Le portefeuille contient un bouton « Demander un retrait TEST ».
Le bouton appelle la RPC Supabase `request_test_withdrawal` avec la session
de l'utilisateur connecté. Aucun insert direct dans `withdrawals` n'est fait.

Test recommandé :
1. Se connecter avec un compte ayant `profiles.role = provider`.
2. Ouvrir « Mon portefeuille ».
3. Choisir USD.
4. Montant : 100.
5. Moyen : Airtel Money.
6. Destination : une valeur fictive, par exemple `TEST-AIRTEL`.
7. Confirmer TEST.
8. Vérifier dans Supabase que `withdrawals` contient une ligne `pending`
   avec `test_mode=true`, et que le compte USD du Provider passe de 950 à 850.

Attention : ce flux est uniquement un test. Il ne contacte pas Airtel Money,
Vodacom M-Pesa ou une banque.
