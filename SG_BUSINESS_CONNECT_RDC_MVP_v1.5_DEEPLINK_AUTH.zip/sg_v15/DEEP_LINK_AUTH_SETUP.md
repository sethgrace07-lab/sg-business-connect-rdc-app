# SG BUSINESS CONNECT RDC v1.5 — Deep Link Auth

Deep link: `sgbusinessconnect://auth/callback/`

Supabase Dashboard → Authentication → URL Configuration → Redirect URLs must contain the same URI.
The Flutter login page uses this URI for password recovery. Android declares the `sgbusinessconnect` scheme.

Build with your normal Flutter toolchain. If Supabase credentials are supplied via --dart-define, use SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY.
