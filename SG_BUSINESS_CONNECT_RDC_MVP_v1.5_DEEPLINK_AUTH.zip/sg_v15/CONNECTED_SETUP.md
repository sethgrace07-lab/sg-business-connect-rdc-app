# Connexion Frontend + Backend

1. Créer le projet Supabase.
2. Exécuter `supabase/schema.sql`.
3. Exécuter `supabase/production_migration.sql`.
4. Lancer l'application avec :
   flutter pub get
   flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_PUBLISHABLE_KEY=...
5. Tester inscription/connexion.
6. Tester publication et recherche.
7. Tester portefeuille et demande de retrait.
8. Créer un profil dont `role = admin` uniquement par une opération d'administration sécurisée.
9. Les paiements réels restent désactivés tant que les comptes/API marchands officiels ne sont pas configurés.

Le client Flutter ne contient pas de secret serveur.
