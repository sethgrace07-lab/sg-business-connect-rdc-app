create extension if not exists pgcrypto;

do $$ begin
  create type public.user_role as enum ('client','company','provider','supplier','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.order_status as enum ('pending','accepted','in_progress','completed','cancelled','disputed');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  whatsapp text,
  city text,
  avatar_url text,
  role public.user_role not null default 'client',
  is_verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  description text,
  phone text,
  whatsapp text,
  city text,
  logo_url text,
  is_verified boolean not null default false,
  rating numeric(3,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  icon text,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  category_id uuid references public.categories(id),
  title text not null,
  description text not null,
  city text,
  budget numeric(14,2),
  currency text not null default 'USD',
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  provider_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(14,2) not null,
  currency text not null default 'USD',
  message text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  provider_id uuid not null references public.profiles(id),
  listing_id uuid references public.listings(id),
  quote_id uuid references public.quotes(id),
  gross_amount numeric(14,2) not null,
  commission_rate numeric(5,2) not null default 5.00,
  commission_amount numeric(14,2) generated always as
    (round(gross_amount * commission_rate / 100, 2)) stored,
  provider_amount numeric(14,2) generated always as
    (round(gross_amount - gross_amount * commission_rate / 100, 2)) stored,
  currency text not null default 'USD',
  status public.order_status not null default 'pending',
  created_at timestamptz not null default now()
);

create index if not exists listings_city_idx on public.listings(city);
create index if not exists companies_city_idx on public.companies(city);
create index if not exists quotes_listing_idx on public.quotes(listing_id);
create index if not exists orders_client_idx on public.orders(client_id);
create index if not exists orders_provider_idx on public.orders(provider_id);

insert into public.categories(name, icon) values
('BTP & Construction','construction'),
('Électricité','electrical_services'),
('Plomberie','plumbing'),
('Nettoyage','cleaning_services'),
('Transport','local_shipping'),
('Informatique','computer'),
('Fournisseurs','inventory_2'),
('Autres services','apps')
on conflict (name) do nothing;

alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.listings enable row level security;
alter table public.quotes enable row level security;
alter table public.orders enable row level security;

create policy if not exists profiles_select on public.profiles
for select using (true);

create policy if not exists profiles_insert_own on public.profiles
for insert with check (auth.uid() = id);

create policy if not exists profiles_update_own on public.profiles
for update using (auth.uid() = id);

create policy if not exists companies_public_read on public.companies
for select using (true);

create policy if not exists companies_owner_write on public.companies
for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy if not exists listings_public_read on public.listings
for select using (true);

create policy if not exists listings_owner_insert on public.listings
for insert with check (auth.uid() = owner_id);

create policy if not exists quotes_provider_insert on public.quotes
for insert with check (auth.uid() = provider_id);

create policy if not exists quotes_participants_read on public.quotes
for select using (
  auth.uid() = provider_id or
  auth.uid() in (select owner_id from public.listings where id = listing_id)
);

create policy if not exists orders_participants_read on public.orders
for select using (auth.uid() = client_id or auth.uid() = provider_id);
