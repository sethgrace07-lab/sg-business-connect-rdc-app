-- Migration additive pour le MVP v0.3 existant.
-- Exécuter après supabase/schema.sql.

create table if not exists public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references public.profiles(id) on delete cascade,
  currency text not null default 'USD',
  available_balance numeric(14,2) not null default 0,
  pending_balance numeric(14,2) not null default 0,
  total_earned numeric(14,2) not null default 0,
  total_withdrawn numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ledger_entries (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  user_id uuid references public.profiles(id),
  transaction_type text not null,
  direction text not null check (direction in ('credit','debit')),
  amount numeric(14,2) not null check (amount >= 0),
  currency text not null default 'USD',
  order_id uuid references public.orders(id),
  provider_reference text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  user_id uuid references public.profiles(id),
  order_id uuid references public.orders(id),
  amount numeric(14,2) not null,
  currency text not null default 'USD',
  method text,
  status text not null default 'pending',
  provider_reference text,
  idempotency_key text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  amount numeric(14,2) not null check (amount > 0),
  method text not null,
  destination text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  plan text not null,
  amount numeric(14,2) not null default 0,
  status text not null default 'active',
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  title text not null,
  budget numeric(14,2) not null,
  status text not null default 'pending',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.verification_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  document_type text not null,
  document_path text not null,
  status text not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  review_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles(id),
  action text not null,
  target_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.wallets enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.transactions enable row level security;
alter table public.withdrawals enable row level security;
alter table public.subscriptions enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.verification_requests enable row level security;

create policy if not exists wallet_owner_read on public.wallets
for select using (auth.uid() = user_id);

create policy if not exists ledger_owner_read on public.ledger_entries
for select using (auth.uid() = user_id);

create policy if not exists transactions_owner_read on public.transactions
for select using (auth.uid() = user_id);

create policy if not exists withdrawals_owner_read on public.withdrawals
for select using (auth.uid() = user_id);

create policy if not exists withdrawals_owner_insert on public.withdrawals
for insert with check (auth.uid() = user_id);

create policy if not exists subscriptions_owner_read on public.subscriptions
for select using (auth.uid() = user_id);

create policy if not exists ads_owner_read on public.ad_campaigns
for select using (auth.uid() = owner_id);

create policy if not exists ads_owner_insert on public.ad_campaigns
for insert with check (auth.uid() = owner_id);

create policy if not exists verification_owner_read on public.verification_requests
for select using (auth.uid() = user_id);
