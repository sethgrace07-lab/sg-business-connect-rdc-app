package com.example.sg_business_connect_rdc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
