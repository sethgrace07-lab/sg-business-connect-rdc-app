class FinanceRules {
  static const double defaultCommissionRate = 0.05;

  static double commission(double amount, {double rate = defaultCommissionRate}) {
    if (amount < 0 || rate < 0 || rate > 1) {
      throw ArgumentError('Montant ou taux invalide');
    }
    return double.parse((amount * rate).toStringAsFixed(2));
  }

  static double providerAmount(double amount, {double rate = defaultCommissionRate}) {
    return double.parse(
      (amount - commission(amount, rate: rate)).toStringAsFixed(2),
    );
  }
}
