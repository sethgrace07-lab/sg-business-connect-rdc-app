import 'package:supabase_flutter/supabase_flutter.dart';

class SgApiService {
  final SupabaseClient client;
  SgApiService({SupabaseClient? client}) : client = client ?? Supabase.instance.client;

  Future<Map<String, dynamic>> health() async {
    final response = await client.functions.invoke(
      'sg-business-connect-api',
      body: {'action': 'health'},
    );
    return _map(response.data);
  }

  Future<Map<String, dynamic>?> wallet() async {
    final response = await client.functions.invoke(
      'sg-business-connect-api',
      body: {'action': 'wallet'},
    );
    final data = _map(response.data);
    final value = data['wallet'];
    return value is Map ? Map<String, dynamic>.from(value) : null;
  }

  Map<String, dynamic> _map(dynamic data) {
    if (data is Map) return Map<String, dynamic>.from(data);
    return {'data': data};
  }
}
