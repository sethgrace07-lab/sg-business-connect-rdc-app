import 'package:supabase_flutter/supabase_flutter.dart';

class RoleService {
  final SupabaseClient client;
  RoleService({SupabaseClient? client}) : client = client ?? Supabase.instance.client;

  Future<String?> myRole() async {
    final user = client.auth.currentUser;
    if (user == null) return null;
    final row = await client.from('profiles').select('role').eq('id', user.id).maybeSingle();
    return row?['role']?.toString().toLowerCase();
  }
}
