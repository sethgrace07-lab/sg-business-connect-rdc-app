import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CreateListingPage extends StatefulWidget {
  const CreateListingPage({super.key});
  @override State<CreateListingPage> createState() => _CreateListingPageState();
}

class _CreateListingPageState extends State<CreateListingPage> {
  final title = TextEditingController();
  final description = TextEditingController();
  final city = TextEditingController();
  final budget = TextEditingController();
  bool loading = false;

  Future<void> publish() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Connectez-vous pour publier.')));
      return;
    }
    if (title.text.trim().isEmpty || description.text.trim().isEmpty) return;

    setState(() => loading = true);
    try {
      await Supabase.instance.client.from('listings').insert({
        'owner_id': user.id,
        'title': title.text.trim(),
        'description': description.text.trim(),
        'city': city.text.trim(),
        'budget': double.tryParse(budget.text.replaceAll(',', '.')),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Opportunité publiée.')));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Publication impossible : $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Publier une opportunité')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      TextField(controller: title,
          decoration: const InputDecoration(labelText: 'Titre')),
      TextField(controller: description, maxLines: 5,
          decoration: const InputDecoration(labelText: 'Description')),
      TextField(controller: city,
          decoration: const InputDecoration(labelText: 'Ville')),
      TextField(controller: budget, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Budget indicatif (USD)')),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : publish,
          child: Text(loading ? 'Publication...' : 'Publier')),
    ]),
  );
}
