import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final query = TextEditingController();
  final city = TextEditingController();
  List<Map<String, dynamic>> results = [];
  bool loading = false;

  Future<void> search() async {
    setState(() => loading = true);
    try {
      var request = Supabase.instance.client.from('companies').select();
      final data = await request;
      final q = query.text.trim().toLowerCase();
      final c = city.text.trim().toLowerCase();

      setState(() {
        results = (data as List)
          .map((e) => Map<String, dynamic>.from(e))
          .where((e) {
            final name = (e['name'] ?? '').toString().toLowerCase();
            final desc = (e['description'] ?? '').toString().toLowerCase();
            final companyCity = (e['city'] ?? '').toString().toLowerCase();
            return (q.isEmpty || name.contains(q) || desc.contains(q)) &&
                   (c.isEmpty || companyCity.contains(c));
          }).toList();
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Recherche impossible : $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Trouver un professionnel')),
    body: Column(children: [
      Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: query,
              decoration: const InputDecoration(
                labelText: 'Service ou entreprise',
                prefixIcon: Icon(Icons.search))),
          TextField(controller: city,
              decoration: const InputDecoration(
                labelText: 'Ville',
                prefixIcon: Icon(Icons.location_on))),
          const SizedBox(height: 10),
          FilledButton.icon(onPressed: loading ? null : search,
            icon: const Icon(Icons.search), label: const Text('Rechercher')),
        ]),
      ),
      Expanded(
        child: loading
          ? const Center(child: CircularProgressIndicator())
          : results.isEmpty
            ? const Center(child: Text('Aucun professionnel trouvé.'))
            : ListView.builder(
                itemCount: results.length,
                itemBuilder: (_, i) {
                  final e = results[i];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text((e['name'] ?? 'S').toString().substring(0, 1).toUpperCase())),
                      title: Text(e['name'] ?? 'Entreprise'),
                      subtitle: Text('${e['city'] ?? ''}\n${e['description'] ?? ''}'),
                      isThreeLine: true,
                      trailing: e['is_verified'] == true
                        ? const Icon(Icons.verified)
                        : null,
                    ),
                  );
                }),
      ),
    ]),
  );
}
