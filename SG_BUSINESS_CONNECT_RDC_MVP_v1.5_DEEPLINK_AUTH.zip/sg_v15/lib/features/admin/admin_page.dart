import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  bool loading = true;
  bool allowed = false;
  List<Map<String, dynamic>> withdrawals = [];

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    final client = Supabase.instance.client;
    try {
      final user = client.auth.currentUser;
      if (user == null) throw Exception('UNAUTHENTICATED');
      final profile = await client.from('profiles').select('role').eq('id', user.id).maybeSingle();
      if (profile?['role']?.toString().toLowerCase() != 'admin') {
        if (mounted) setState(() { allowed = false; loading = false; });
        return;
      }
      final rows = await client.from('withdrawals').select('id,user_id,amount,currency,status,provider,destination_reference,fee,net_amount,test_mode,created_at,admin_note,rejection_reason').order('created_at', ascending: false);
      if (mounted) setState(() { allowed = true; withdrawals = List<Map<String,dynamic>>.from(rows); loading = false; });
    } catch (e) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> review(String id, String action) async {
    String? note;
    if (action == 'reject') {
      note = await showDialog<String>(context: context, builder: (c) {
        final controller = TextEditingController();
        return AlertDialog(title: const Text('Motif du rejet'), content: TextField(controller: controller, decoration: const InputDecoration(labelText: 'Motif')), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(c, controller.text.trim()), child: const Text('Rejeter'))]);
      });
      if (note == null || note!.isEmpty) return;
    }
    try {
      final result = await Supabase.instance.client.rpc('admin_review_withdrawal', params: {'p_withdrawal_id': id, 'p_action': action, 'p_note': note});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Action réussie : ${result['action']}')));
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Action refusée : $e')));
    }
  }

  Widget actions(Map<String,dynamic> w) {
    final id = w['id'].toString();
    switch (w['status']) {
      case 'pending': return Wrap(spacing: 8, children: [OutlinedButton(onPressed: () => review(id,'reject'), child: const Text('Rejeter')), FilledButton(onPressed: () => review(id,'approve'), child: const Text('Approuver'))]);
      case 'approved': return FilledButton(onPressed: () => review(id,'process'), child: const Text('Mettre en traitement'));
      case 'processing': return FilledButton(onPressed: () => review(id,'pay'), child: const Text('Marquer payé'));
      default: return const Text('Aucune action');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!allowed) return const Scaffold(body: Center(child: Text('Accès administrateur non autorisé.')));
    return Scaffold(
      appBar: AppBar(title: const Text('Administration — Retraits'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh)), IconButton(onPressed: () async { await Supabase.instance.client.auth.signOut(); if (mounted) Navigator.of(context).popUntil((r) => r.isFirst); }, icon: const Icon(Icons.logout))]),
      body: withdrawals.isEmpty ? const Center(child: Text('Aucun retrait.')) : RefreshIndicator(onRefresh: load, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount: withdrawals.length, itemBuilder: (_, i) { final w = withdrawals[i]; return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${w['amount']} ${w['currency']} — ${w['status']}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${w['provider']} • ${w['destination_reference']}'), if (w['test_mode'] == true) const Chip(label: Text('TEST')), const SizedBox(height: 8), actions(w)]))); })),
    );
  }
}
