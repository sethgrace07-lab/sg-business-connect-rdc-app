import 'package:flutter/material.dart';
import 'wallet_service.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  final service = WalletService();
  List<Map<String, dynamic>> accounts = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final data = await service.getMyWalletAccounts();
      if (mounted) setState(() { accounts = data; loading = false; });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  double _num(dynamic v) => double.tryParse('$v') ?? 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mon portefeuille')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    child: const ListTile(
                      leading: Icon(Icons.verified_user),
                      title: Text('Mode TEST'),
                      subtitle: Text('Aucun retrait réel n\'est envoyé à Airtel, M-Pesa ou la banque.'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...accounts.map((a) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.account_balance_wallet),
                          title: Text('${a['currency_code']} — Solde disponible'),
                          subtitle: Text('${a['balance'] ?? 0}'),
                        ),
                      )),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () => _withdraw(context),
                    icon: const Icon(Icons.currency_exchange),
                    label: const Text('Demander un retrait TEST'),
                  ),
                ],
              ),
            ),
    );
  }

  Future<void> _withdraw(BuildContext context) async {
    final amount = TextEditingController(text: '100');
    final destination = TextEditingController();
    String method = 'Airtel Money';
    String currency = 'USD';
    bool sending = false;

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Retrait TEST'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: amount,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Montant'),
                ),
                DropdownButtonFormField<String>(
                  value: currency,
                  items: const [
                    DropdownMenuItem(value: 'USD', child: Text('USD — Dollar américain')),
                    DropdownMenuItem(value: 'CDF', child: Text('CDF — Franc congolais')),
                    DropdownMenuItem(value: 'EUR', child: Text('EUR — Euro')),
                  ],
                  onChanged: (v) => setDialogState(() => currency = v ?? currency),
                  decoration: const InputDecoration(labelText: 'Devise'),
                ),
                DropdownButtonFormField<String>(
                  value: method,
                  items: const [
                    DropdownMenuItem(value: 'Airtel Money', child: Text('Airtel Money')),
                    DropdownMenuItem(value: 'M-Pesa', child: Text('Vodacom M-Pesa')),
                    DropdownMenuItem(value: 'Banque', child: Text('Compte bancaire')),
                  ],
                  onChanged: (v) => setDialogState(() => method = v ?? method),
                  decoration: const InputDecoration(labelText: 'Moyen de retrait'),
                ),
                TextField(
                  controller: destination,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Numéro / compte de TEST'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: sending ? null : () => Navigator.pop(context), child: const Text('Annuler')),
            FilledButton(
              onPressed: sending ? null : () async {
                final value = double.tryParse(amount.text.replaceAll(',', '.'));
                if (value == null || value <= 0 || destination.text.trim().isEmpty) {
                  ScaffoldMessenger.of(this.context).showSnackBar(
                    const SnackBar(content: Text('Montant et destination obligatoires.')),
                  );
                  return;
                }
                setDialogState(() => sending = true);
                try {
                  final result = await service.requestTestWithdrawal(
                    amount: value,
                    currency: currency,
                    method: method,
                    destination: destination.text.trim(),
                  );
                  if (context.mounted) Navigator.pop(context);
                  if (mounted) {
                    await load();
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      SnackBar(content: Text('Retrait TEST créé : ${result['amount']} ${result['currency']} — ${result['status']}')),
                    );
                  }
                } catch (e) {
                  setDialogState(() => sending = false);
                  if (mounted) {
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      SnackBar(content: Text('Échec du retrait TEST : $e')),
                    );
                  }
                }
              },
              child: Text(sending ? 'Traitement…' : 'Confirmer TEST'),
            ),
          ],
        ),
      ),
    );
  }
}
