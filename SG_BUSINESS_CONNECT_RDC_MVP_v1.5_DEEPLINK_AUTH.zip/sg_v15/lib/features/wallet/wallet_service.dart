import 'package:supabase_flutter/supabase_flutter.dart';

class WalletService {
  final SupabaseClient client;
  WalletService({SupabaseClient? client})
      : client = client ?? Supabase.instance.client;

  Future<Map<String, dynamic>?> getMyWallet() async {
    final user = client.auth.currentUser;
    if (user == null) return null;
    final rows = await client
        .from('wallets')
        .select()
        .eq('user_id', user.id)
        .maybeSingle();
    return rows == null ? null : Map<String, dynamic>.from(rows);
  }

  Future<List<Map<String, dynamic>>> getMyWalletAccounts() async {
    final user = client.auth.currentUser;
    if (user == null) return [];
    final rows = await client
        .from('wallet_accounts')
        .select('id, wallet_id, currency_code, balance, pending_balance, total_earned, total_withdrawn')
        .eq('wallet_id', await _walletId(user.id))
        .order('currency_code');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<String?> _walletId(String userId) async {
    final row = await client.from('wallets').select('id').eq('user_id', userId).maybeSingle();
    return row?['id'] as String?;
  }

  Future<List<Map<String, dynamic>>> getMyTransactions() async {
    final user = client.auth.currentUser;
    if (user == null) return [];
    final rows = await client
        .from('transactions')
        .select()
        .eq('user_id', user.id)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  /// Calls the protected RPC. The RPC uses auth.uid() and is intentionally
  /// not implemented as a direct client insert into withdrawals.
  Future<Map<String, dynamic>> requestTestWithdrawal({
    required double amount,
    required String currency,
    required String method,
    required String destination,
  }) async {
    if (client.auth.currentUser == null) {
      throw Exception('Utilisateur non connecté');
    }
    final provider = switch (method) {
      'Airtel Money' => 'airtel_money',
      'M-Pesa' => 'vodacom_mpesa',
      'Banque' => 'bank',
      _ => 'internal_test',
    };
    final data = await client.rpc('request_test_withdrawal', params: {
      'p_amount': amount,
      'p_currency': currency,
      'p_method': provider,
      'p_destination': destination,
    });
    return Map<String, dynamic>.from(data as Map);
  }
}
