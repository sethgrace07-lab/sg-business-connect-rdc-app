import 'package:flutter/material.dart';
import '../marketplace/search_page.dart';
import '../marketplace/create_listing_page.dart';
import '../dashboard/dashboard_page.dart';
import '../admin/admin_page.dart';
import '../../core/role_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? role;
  @override void initState() { super.initState(); RoleService().myRole().then((v) { if (mounted) setState(() => role = v); }); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('SG BUSINESS CONNECT RDC'),
      actions: [
        IconButton(
          tooltip: 'Tableau de bord',
          onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const DashboardPage())),
          icon: const Icon(Icons.dashboard),
        ),
      ],
    ),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text('Connectons les opportunités aux professionnels.',
          style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 18),
      FilledButton.icon(
        onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const SearchPage())),
        icon: const Icon(Icons.search),
        label: const Text('Rechercher un professionnel'),
      ),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const CreateListingPage())),
        icon: const Icon(Icons.add_business),
        label: const Text('Publier une opportunité'),
      ),
      const SizedBox(height: 24),
      const Text('Catégories populaires',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8, runSpacing: 8,
        children: const [
          Chip(label: Text('BTP')),
          Chip(label: Text('Électricité')),
          Chip(label: Text('Plomberie')),
          Chip(label: Text('Nettoyage')),
          Chip(label: Text('Transport')),
          Chip(label: Text('Informatique')),
          Chip(label: Text('Fournisseurs')),
        ],
      ),
      const SizedBox(height: 24),
      if (role == 'admin') Card(
        child: ListTile(
          leading: const Icon(Icons.admin_panel_settings),
          title: const Text('Administration'),
          subtitle: const Text('Gestion sécurisée des retraits'),
          onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AdminPage())),
        ),
      ),
    ]),
  );
}
