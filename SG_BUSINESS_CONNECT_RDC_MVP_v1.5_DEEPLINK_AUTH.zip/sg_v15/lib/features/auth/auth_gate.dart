import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/role_service.dart';
import '../home/home_page.dart';
import '../admin/admin_page.dart';
import 'login_page.dart';

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final roles = RoleService();
  bool loading = true;
  String? role;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null) { if (mounted) setState(() => loading = false); return; }
    try { role = await roles.myRole(); } catch (_) { role = null; }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (Supabase.instance.client.auth.currentSession == null) return const LoginPage();
    return role == 'admin' ? const AdminPage() : const HomePage();
  }
}
