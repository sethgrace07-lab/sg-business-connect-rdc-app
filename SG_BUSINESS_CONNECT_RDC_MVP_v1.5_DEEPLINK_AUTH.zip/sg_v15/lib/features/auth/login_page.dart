import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../home/home_page.dart';
import 'register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      if (mounted) {
        Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const HomePage()));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Connexion impossible : $e')));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> resetPassword() async {
    final value = email.text.trim();
    if (value.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Entrez votre e-mail.')));
      return;
    }
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(
        value,
        redirectTo: 'sgbusinessconnect://auth/callback/',
      );
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lien de récupération envoyé.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Impossible d'envoyer le lien : $e')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Connexion')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('SG BUSINESS CONNECT RDC',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      TextField(controller: email,
          decoration: const InputDecoration(labelText: 'E-mail')),
      TextField(controller: password, obscureText: true,
          decoration: const InputDecoration(labelText: 'Mot de passe')),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : login,
          child: Text(loading ? 'Connexion...' : 'Se connecter')),
      TextButton(onPressed: resetPassword, child: const Text('Mot de passe oublié ?')),
      TextButton(
        onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const RegisterPage())),
        child: const Text('Créer un compte'),
      ),
    ]),
  );
}
