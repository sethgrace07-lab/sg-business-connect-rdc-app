import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();
  String role = 'client';
  bool loading = false;

  Future<void> register() async {
    setState(() => loading = true);
    try {
      final result = await Supabase.instance.client.auth.signUp(
        email: email.text.trim(),
        password: password.text,
        data: {
          'full_name': name.text.trim(),
          'phone': phone.text.trim(),
          'role': role,
        },
      );
      if (result.user != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Compte créé. Vérifiez votre e-mail si nécessaire.')));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Inscription impossible : $e')));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Créer un compte')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      TextField(controller: name,
          decoration: const InputDecoration(labelText: 'Nom complet')),
      TextField(controller: email,
          decoration: const InputDecoration(labelText: 'E-mail')),
      TextField(controller: phone,
          decoration: const InputDecoration(labelText: 'Téléphone / WhatsApp')),
      DropdownButtonFormField<String>(
        value: role,
        decoration: const InputDecoration(labelText: 'Type de compte'),
        items: const [
          DropdownMenuItem(value: 'client', child: Text('Client')),
          DropdownMenuItem(value: 'company', child: Text('Entreprise')),
          DropdownMenuItem(value: 'provider', child: Text('Prestataire')),
          DropdownMenuItem(value: 'supplier', child: Text('Fournisseur')),
        ],
        onChanged: (v) => setState(() => role = v ?? 'client'),
      ),
      TextField(controller: password, obscureText: true,
          decoration: const InputDecoration(labelText: 'Mot de passe')),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : register,
          child: Text(loading ? 'Création...' : 'Créer mon compte')),
    ]),
  );
}
