import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'login_page.dart';

class UpdatePasswordPage extends StatefulWidget {
  const UpdatePasswordPage({super.key});
  @override State<UpdatePasswordPage> createState() => _UpdatePasswordPageState();
}

class _UpdatePasswordPageState extends State<UpdatePasswordPage> {
  final password = TextEditingController();
  final confirm = TextEditingController();
  bool loading = false;

  Future<void> update() async {
    if (password.text.length < 8 || password.text != confirm.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mot de passe : 8 caractères minimum et confirmation identique.')));
      return;
    }
    setState(() => loading = true);
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(password: password.text));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mot de passe mis à jour.')));
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Échec : $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nouveau mot de passe')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Définissez votre nouveau mot de passe.', style: TextStyle(fontSize: 18)),
      const SizedBox(height: 20),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Nouveau mot de passe')),
      TextField(controller: confirm, obscureText: true, decoration: const InputDecoration(labelText: 'Confirmer le mot de passe')),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : update, child: Text(loading ? 'Enregistrement...' : 'Enregistrer')),
    ]),
  );
}
