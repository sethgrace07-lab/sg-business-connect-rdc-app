import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/sg_api_service.dart';
import '../wallet/wallet_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final api = SgApiService();
  Map<String, dynamic>? wallet;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await api.wallet();
      if (mounted) setState(() { wallet = data; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> logout() async {
    await Supabase.instance.client.auth.signOut();
    if (mounted) Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final available = wallet?['available_balance'] ?? 0;
    final pending = wallet?['pending_balance'] ?? 0;
    final earned = wallet?['total_earned'] ?? 0;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mon tableau de bord'),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (error != null) Card(child: ListTile(
              leading: const Icon(Icons.error_outline),
              title: const Text('Connexion Supabase/API impossible'),
              subtitle: Text(error!),
            )),
            if (loading) const LinearProgressIndicator(),
            Card(child: ListTile(
              leading: const Icon(Icons.account_balance_wallet),
              title: const Text('Solde disponible'),
              subtitle: Text('$available USD'),
            )),
            Card(child: ListTile(
              title: const Text('Solde en attente'),
              subtitle: Text('$pending USD'),
            )),
            Card(child: ListTile(
              title: const Text('Total gagné'),
              subtitle: Text('$earned USD'),
            )),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const WalletPage())),
              icon: const Icon(Icons.payments),
              label: const Text('Ouvrir mon portefeuille'),
            ),
          ],
        ),
      ),
    );
  }
}
