import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/supabase_config.dart';
import 'features/auth/auth_gate.dart';
import 'features/auth/update_password_page.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
StreamSubscription<Uri>? _deepLinkSubscription;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (SupabaseConfig.isConfigured) {
    await Supabase.initialize(
      url: SupabaseConfig.url,
      publishableKey: SupabaseConfig.publishableKey,
    );
    _setupAuthAndDeepLinks();
  }
  runApp(const SGBusinessConnectApp());
}

Future<void> _setupAuthAndDeepLinks() async {
  final client = Supabase.instance.client;
  client.auth.onAuthStateChange.listen((data) {
    if (data.event == AuthChangeEvent.passwordRecovery) {
      navigatorKey.currentState?.push(
        MaterialPageRoute(builder: (_) => const UpdatePasswordPage()),
      );
    }
  });

  final appLinks = AppLinks();
  try {
    final initialUri = await appLinks.getInitialLink();
    if (initialUri != null) {
      await _handleDeepLink(initialUri);
    }
  } catch (_) {}

  _deepLinkSubscription = appLinks.uriLinkStream.listen((uri) {
    _handleDeepLink(uri);
  });
}

Future<void> _handleDeepLink(Uri uri) async {
  if (uri.scheme != 'sgbusinessconnect' || uri.host != 'auth') return;
  try {
    await Supabase.instance.client.auth.getSessionFromUrl(uri);
  } catch (_) {
    // Invalid/expired links are handled by the recovery screen or login flow.
  }
}

class SGBusinessConnectApp extends StatelessWidget {
  const SGBusinessConnectApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    navigatorKey: navigatorKey,
    title: 'SG BUSINESS CONNECT RDC',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber),
      useMaterial3: true,
    ),
    home: const AuthGate(),
  );
}
