# SG BUSINESS CONNECT RDC — MVP v0.3

Version enrichie du MVP avec :
- accueil et navigation ;
- inscription / connexion ;
- profils professionnels ;
- publication d'opportunités ;
- recherche et filtrage ;
- consultation des professionnels ;
- demande de devis ;
- commandes ;
- calcul des commissions ;
- tableau de bord ;
- administration de base.

Paiements réels Airtel Money / M-Pesa / banque : mode test uniquement dans cette version.
